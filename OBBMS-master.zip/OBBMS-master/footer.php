<footer class="footer">
  <div class="contianer">
    <div class="row">
      <div class="col-md-12"><img src="logod.png" alt="donate blood" width="211"/>
        <div class="col-md-3"></div>
        <div class="col-md-6">
          <ul>
            <li>
            <a href="blood.php">Home</a></li>
            <li><a href="mission.php">About Us</a></li>
            <li><a href="gallery.php">Gallery</a></li>
            <li><a href="register.php">Donor Registration</a></li>
            <li><a href="contact.php">Contact Us</a></li>
          </ul>
          
          <div class="col-md-3" style="width:680px;font-family: courier;">
          
         @copyright 2017.Blood Bank Information Managment System.All Rights Reserved
          </br>
    Project from Anisha Sapkota,Devendra Giri,Dhiraj Katwal & Kamala Khatiwada</div>
        </div>
      </div>
    </div>
  </div>
</footer>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script> 
<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="js/bootstrap.min.js"></script>
</body>
</html>