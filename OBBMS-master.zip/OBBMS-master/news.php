<?php
include('header.php');
?>
<div class="hom1">
  <div class="container">
    <div class="row">
      <div class="col-md-9">
        <div class="row">
          <div class="col-md-6">
          <div class="nabin">

<h3 class="h3news" style="float:left;color:red">Helping to the flood victims  </h3></br></br>
<h6 class="h4news" style="margin:12px;color:blue">2074/05/10, Saturday </h6></br>
<p style="color:black;margin-top:2px">Godawari Blood Donor committee, Nepal is organizing an program with the association of sushma college,itahari 
by providing financial and clothing donation to the flood victims in itahari and raising awareness programs towards making the environment clean and balanced.[…]</p>

</div>

        </div>
      </div>
    </div>
  </div>
</div>


<div class="hom1">
  <div class="container">
    <div class="row">
      <div class="col-md-9">
        <div class="row">
          <div class="col-md-6">
          <div class="nabin">

<h3 class="h3news" style="float:left;color:red">on the occassion of democracy day</h3></br></br>
<h6 class="h4news" style="margin:12px;color:blue">2074/1/11, Monday, 11:00 am </h6></br>
<p style="color:black;margin-top:2px">Godawari Blood Donor committee, Nepal is organizing an interaction program among the youths of different organization and colleges about the role of youths 
in Blood Movement with the  support of Nepal Government. Blood Management have been the big issue due to scarcity. We believe Youths are the future 
blood donors and want to gather youths all around […]</p>

</div>

        </div>
      </div>
    </div>
  </div>
</div>

<div class="hom1">
  <div class="container">
    <div class="row">
      <div class="col-md-9">
        <div class="row">
          <div class="col-md-6">
          <div class="nabin">

<h3 class="h3news" style="float:left;color:red">World Blood Donor Day donation camp</h3></br></br>
<h6 class="h4news" style="margin:12px;color:blue">2074/2/27, Saturday, 10:00 AM</h6></br>
<p style="color:black;margin-top:2px">A blood donation camp was held at Godawari college,Itahari on the occassion of World Blood Donor Day 2017.  The program was jointly organised by Pragati Youth Club</br>
 and Jansayog Youth Club under the supervision of Blood Donors Association Nepal. Co-organizers for the event were Youth for Human Rights International Nepal Chapter, Listeren’s Club Nepal, Desh Darshan, Scouting 4Peace and Mirmire Yuba Samaj.
The programs aimed to collect 200 pints of blood.</p>

</div>

        </div>
      </div>
    </div>
  </div>
</div>

<?php
include('footer.php');
?>